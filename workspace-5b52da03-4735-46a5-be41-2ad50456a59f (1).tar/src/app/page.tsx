'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Server, Clock, Download, Plus, Settings, Trash2, Play, CheckCircle, XCircle, FileDown, RefreshCw, Activity } from 'lucide-react'

interface MikrotikDevice {
  id: string
  name: string
  host: string
  port: number
  username: string
  password: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface Backup {
  id: string
  deviceId: string
  filename: string
  size: number
  backupType: string
  status: string
  errorMessage?: string
  createdAt: string
}

interface BackupSchedule {
  id: string
  deviceId: string
  name: string
  cronExpression: string
  backupType: string
  isActive: boolean
  lastRun?: string
  nextRun?: string
  createdAt: string
}

export default function Home() {
  const [devices, setDevices] = useState<MikrotikDevice[]>([])
  const [backups, setBackups] = useState<Backup[]>([])
  const [schedules, setSchedules] = useState<BackupSchedule[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddDevice, setShowAddDevice] = useState(false)
  const [showAddSchedule, setShowAddSchedule] = useState(false)
  const [testingConnection, setTestingConnection] = useState<string | null>(null)
  const [creatingBackup, setCreatingBackup] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)

  const [newDevice, setNewDevice] = useState({
    name: '',
    host: '',
    port: 8728,
    username: '',
    password: ''
  })

  const [newSchedule, setNewSchedule] = useState({
    deviceId: '',
    name: '',
    cronExpression: '0 2 * * *',
    backupType: 'full'
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [devicesRes, backupsRes, schedulesRes] = await Promise.all([
        fetch('/api/devices'),
        fetch('/api/backups'),
        fetch('/api/schedules')
      ])

      if (devicesRes.ok) {
        const devicesData = await devicesRes.json()
        setDevices(devicesData)
      }

      if (backupsRes.ok) {
        const backupsData = await backupsRes.json()
        setBackups(backupsData)
      }

      if (schedulesRes.ok) {
        const schedulesData = await schedulesRes.json()
        setSchedules(schedulesData)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddDevice = async () => {
    try {
      const response = await fetch('/api/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newDevice)
      })

      if (response.ok) {
        setShowAddDevice(false)
        setNewDevice({ name: '', host: '', port: 8728, username: '', password: '' })
        fetchData()
      }
    } catch (error) {
      console.error('Error adding device:', error)
    }
  }

  const handleTestConnection = async (deviceId: string) => {
    setTestingConnection(deviceId)
    try {
      const response = await fetch(`/api/devices/${deviceId}/test`, {
        method: 'POST'
      })
      
      if (!response.ok) {
        const errorData = await response.text()
        throw new Error(`HTTP ${response.status}: ${errorData}`)
      }
      
      const result = await response.json()
      
      if (result.success) {
        alert(`✅ Koneksi berhasil!\n\nDevice: ${result.details.deviceName}\nHost: ${result.details.host}\nPort: ${result.details.port}\nUsername: ${result.details.username}\nConnected at: ${new Date(result.details.connectedAt).toLocaleString('id-ID')}`)
      } else {
        alert(`❌ Koneksi gagal: ${result.error}`)
      }
    } catch (error) {
      console.error('Connection test error:', error)
      alert(`❌ Koneksi gagal: ${error.message}`)
    } finally {
      setTestingConnection(null)
    }
  }

  const handleCreateBackup = async (deviceId: string) => {
    setCreatingBackup(deviceId)
    try {
      const response = await fetch('/api/backups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId, backupType: 'full' })
      })

      if (response.ok) {
        fetchData()
      }
    } catch (error) {
      console.error('Error creating backup:', error)
    } finally {
      setCreatingBackup(null)
    }
  }

  const handleDownloadBackup = async (backupId: string, filename: string) => {
    try {
      const response = await fetch(`/api/backups/${backupId}/download`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = filename
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error('Error downloading backup:', error)
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    try {
      await fetchData()
    } finally {
      setRefreshing(false)
    }
  }

  const handleHealthCheck = async () => {
    try {
      const response = await fetch('/api/health')
      const health = await response.json()
      
      if (health.status === 'healthy') {
        alert(`✅ System Health: Good\n\nDatabase: ${health.database}\nVersion: ${health.version}\nTimestamp: ${new Date(health.timestamp).toLocaleString('id-ID')}`)
      } else {
        alert(`❌ System Health: Issues detected\n\nDatabase: ${health.database}\nError: ${health.error}`)
      }
    } catch (error) {
      alert(`❌ Health check failed: ${error.message}`)
    }
  }

  const handleAddSchedule = async () => {
    try {
      const response = await fetch('/api/schedules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSchedule)
      })

      if (response.ok) {
        setShowAddSchedule(false)
        setNewSchedule({ deviceId: '', name: '', cronExpression: '0 2 * * *', backupType: 'full' })
        fetchData()
      }
    } catch (error) {
      console.error('Error adding schedule:', error)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('id-ID')
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mikrotik Daily Backup</h1>
          <p className="text-muted-foreground">Kelola backup otomatis untuk perangkat Mikrotik Anda</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleHealthCheck}
          >
            <Activity className="h-4 w-4 mr-2" />
            Health
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            {refreshing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
            Refresh
          </Button>
          <Dialog open={showAddDevice} onOpenChange={setShowAddDevice}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Tambah Device
              </Button>
            </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Tambah Device Mikrotik</DialogTitle>
              <DialogDescription>
                Tambahkan perangkat Mikrotik baru untuk backup otomatis
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Nama Device</Label>
                <Input
                  id="name"
                  value={newDevice.name}
                  onChange={(e) => setNewDevice({ ...newDevice, name: e.target.value })}
                  placeholder="Router Utama"
                />
              </div>
              <div>
                <Label htmlFor="host">Host/IP Address</Label>
                <Input
                  id="host"
                  value={newDevice.host}
                  onChange={(e) => setNewDevice({ ...newDevice, host: e.target.value })}
                  placeholder="192.168.1.1"
                />
              </div>
              <div>
                <Label htmlFor="port">Port API</Label>
                <Input
                  id="port"
                  type="number"
                  value={newDevice.port}
                  onChange={(e) => setNewDevice({ ...newDevice, port: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={newDevice.username}
                  onChange={(e) => setNewDevice({ ...newDevice, username: e.target.value })}
                  placeholder="admin"
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={newDevice.password}
                  onChange={(e) => setNewDevice({ ...newDevice, password: e.target.value })}
                />
              </div>
              <Button onClick={handleAddDevice} className="w-full">
                Tambah Device
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="devices" className="space-y-4">
        <TabsList>
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="backups">Backup History</TabsTrigger>
          <TabsTrigger value="schedules">Jadwal Backup</TabsTrigger>
        </TabsList>

        <TabsContent value="devices" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {devices.map((device) => (
              <Card key={device.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Server className="h-5 w-5" />
                      {device.name}
                    </CardTitle>
                    <Badge variant={device.isActive ? "default" : "secondary"}>
                      {device.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <CardDescription>
                    {device.host}:{device.port}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    <p>Username: {device.username}</p>
                    <p>Dibuat: {formatDate(device.createdAt)}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleTestConnection(device.id)}
                      disabled={testingConnection === device.id}
                    >
                      {testingConnection === device.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Settings className="h-4 w-4" />
                      )}
                      Test
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleCreateBackup(device.id)}
                      disabled={creatingBackup === device.id}
                    >
                      {creatingBackup === device.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Download className="h-4 w-4" />
                      )}
                      Backup
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="backups" className="space-y-4">
          <div className="rounded-md border">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    <th className="p-4 text-left">Device</th>
                    <th className="p-4 text-left">Filename</th>
                    <th className="p-4 text-left">Type</th>
                    <th className="p-4 text-left">Size</th>
                    <th className="p-4 text-left">Status</th>
                    <th className="p-4 text-left">Created</th>
                    <th className="p-4 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {backups.map((backup) => {
                    const device = devices.find(d => d.id === backup.deviceId)
                    return (
                      <tr key={backup.id} className="border-b">
                        <td className="p-4">{device?.name || 'Unknown'}</td>
                        <td className="p-4 font-mono text-sm">{backup.filename}</td>
                        <td className="p-4">
                          <Badge variant="outline">{backup.backupType}</Badge>
                        </td>
                        <td className="p-4">{formatFileSize(backup.size)}</td>
                        <td className="p-4">
                          <Badge variant={backup.status === 'success' ? 'default' : 'destructive'}>
                            {backup.status === 'success' ? (
                              <CheckCircle className="h-3 w-3 mr-1" />
                            ) : (
                              <XCircle className="h-3 w-3 mr-1" />
                            )}
                            {backup.status}
                          </Badge>
                        </td>
                        <td className="p-4 text-sm">{formatDate(backup.createdAt)}</td>
                        <td className="p-4">
                          {backup.status === 'success' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDownloadBackup(backup.id, backup.filename)}
                            >
                              <FileDown className="h-4 w-4" />
                            </Button>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
              {backups.length === 0 && (
                <div className="p-8 text-center text-muted-foreground">
                  Belum ada backup yang tersedia
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="schedules" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Jadwal Backup Otomatis</h3>
            <Dialog open={showAddSchedule} onOpenChange={setShowAddSchedule}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Tambah Jadwal
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Tambah Jadwal Backup</DialogTitle>
                  <DialogDescription>
                    Buat jadwal backup otomatis untuk device
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="scheduleDevice">Device</Label>
                    <Select value={newSchedule.deviceId} onValueChange={(value) => setNewSchedule({ ...newSchedule, deviceId: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih device" />
                      </SelectTrigger>
                      <SelectContent>
                        {devices.map((device) => (
                          <SelectItem key={device.id} value={device.id}>
                            {device.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="scheduleName">Nama Jadwal</Label>
                    <Input
                      id="scheduleName"
                      value={newSchedule.name}
                      onChange={(e) => setNewSchedule({ ...newSchedule, name: e.target.value })}
                      placeholder="Backup Harian"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cronExpression">Cron Expression</Label>
                    <Input
                      id="cronExpression"
                      value={newSchedule.cronExpression}
                      onChange={(e) => setNewSchedule({ ...newSchedule, cronExpression: e.target.value })}
                      placeholder="0 2 * * *"
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Format: Menit Jam Hari Bulan HariMinggu (Contoh: 0 2 * * * = Setiap hari jam 2 pagi)
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="backupType">Tipe Backup</Label>
                    <Select value={newSchedule.backupType} onValueChange={(value) => setNewSchedule({ ...newSchedule, backupType: value })}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full">Full Backup</SelectItem>
                        <SelectItem value="config-only">Config Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleAddSchedule} className="w-full">
                    Tambah Jadwal
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {schedules.map((schedule) => {
              const device = devices.find(d => d.id === schedule.deviceId)
              return (
                <Card key={schedule.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <Clock className="h-5 w-5" />
                        {schedule.name}
                      </CardTitle>
                      <Switch checked={schedule.isActive} />
                    </div>
                    <CardDescription>
                      {device?.name || 'Unknown Device'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm space-y-1">
                      <p><strong>Cron:</strong> {schedule.cronExpression}</p>
                      <p><strong>Type:</strong> {schedule.backupType}</p>
                      {schedule.lastRun && (
                        <p><strong>Last Run:</strong> {formatDate(schedule.lastRun)}</p>
                      )}
                      {schedule.nextRun && (
                        <p><strong>Next Run:</strong> {formatDate(schedule.nextRun)}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}