import { backupScheduler } from './backup-scheduler'

// Initialize the backup scheduler when this module is imported
// eslint-disable-next-line @typescript-eslint/no-unused-expressions
backupScheduler