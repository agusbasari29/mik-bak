import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { backupScheduler } from '@/lib/backup-scheduler'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { isActive } = body

    const schedule = await db.backupSchedule.update({
      where: { id: params.id },
      data: { isActive }
    })

    // Update scheduler
    await backupScheduler.updateSchedule(schedule)

    return NextResponse.json(schedule)
  } catch (error) {
    console.error('Error updating schedule:', error)
    return NextResponse.json({ error: 'Failed to update schedule' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.backupSchedule.delete({
      where: { id: params.id }
    })

    // Remove from scheduler
    await backupScheduler.removeSchedule(params.id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting schedule:', error)
    return NextResponse.json({ error: 'Failed to delete schedule' }, { status: 500 })
  }
}