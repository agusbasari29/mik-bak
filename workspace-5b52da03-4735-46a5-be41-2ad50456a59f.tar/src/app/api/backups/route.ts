import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { MikrotikAPI } from '@/lib/mikrotik-api'

export async function GET() {
  try {
    const backups = await db.backup.findMany({
      include: {
        device: {
          select: {
            name: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(backups)
  } catch (error) {
    console.error('Error fetching backups:', error)
    return NextResponse.json({ error: 'Failed to fetch backups' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { deviceId, backupType } = body

    if (!deviceId) {
      return NextResponse.json({ error: 'Device ID is required' }, { status: 400 })
    }

    const device = await db.mikrotikDevice.findUnique({
      where: { id: deviceId }
    })

    if (!device) {
      return NextResponse.json({ error: 'Device not found' }, { status: 404 })
    }

    // Create backup record with pending status
    const backup = await db.backup.create({
      data: {
        deviceId,
        filename: `backup-${device.name}-${new Date().toISOString().replace(/[:.]/g, '-')}.backup`,
        backupType: backupType || 'full',
        status: 'pending',
        size: 0,
        content: ''
      }
    })

    try {
      const api = new MikrotikAPI(device.host, device.port, device.username, device.password)
      const backupData = await api.createBackup(backupType || 'full')

      // Update backup record with success
      const updatedBackup = await db.backup.update({
        where: { id: backup.id },
        data: {
          content: backupData.content,
          size: backupData.size,
          status: 'success'
        }
      })

      return NextResponse.json(updatedBackup, { status: 201 })
    } catch (backupError) {
      // Update backup record with error
      await db.backup.update({
        where: { id: backup.id },
        data: {
          status: 'failed',
          errorMessage: backupError.message
        }
      })
      throw backupError
    }
  } catch (error) {
    console.error('Error creating backup:', error)
    return NextResponse.json({ error: 'Failed to create backup' }, { status: 500 })
  }
}