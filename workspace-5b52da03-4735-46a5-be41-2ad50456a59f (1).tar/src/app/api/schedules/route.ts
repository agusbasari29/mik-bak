import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const schedules = await db.backupSchedule.findMany({
      include: {
        device: {
          select: {
            name: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json(schedules)
  } catch (error) {
    console.error('Error fetching schedules:', error)
    return NextResponse.json({ error: 'Failed to fetch schedules' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { deviceId, name, cronExpression, backupType } = body

    if (!deviceId || !name || !cronExpression) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const schedule = await db.backupSchedule.create({
      data: {
        deviceId,
        name,
        cronExpression,
        backupType: backupType || 'full'
      }
    })

    return NextResponse.json(schedule, { status: 201 })
  } catch (error) {
    console.error('Error creating schedule:', error)
    return NextResponse.json({ error: 'Failed to create schedule' }, { status: 500 })
  }
}