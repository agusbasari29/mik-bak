# 🚀 Cara Penggunaan Mikrotik Daily Backup

## 📋 Prasyarat

- Pastikan Anda memiliki akses ke perangkat Mikrotik
- API Mikrotik harus diaktifkan pada perangkat
- Port API default: 8728

## 🔧 Konfigurasi Mikrotik

### 1. Aktifkan API Service

```bash
# Masuk ke Mikrotik via Terminal/Winbox
# Jalankan perintah berikut:

/ip service enable api
/ip service set api port=8728 address=0.0.0.0
```

### 2. Buat User untuk Backup (Recommended)

```bash
# Buat user khusus untuk backup
/user add name=backup password=backup123 group=read
# Atau gunakan group full untuk akses lengkap
/user add name=backup password=backup123 group=full
```

### 3. Keamanan (Optional)

```bash
# Batasi akses API ke IP tertentu saja
/ip service set api address=192.168.1.100
# Ganti 192.168.1.100 dengan IP server backup Anda
```

## 🖥️ Penggunaan Aplikasi

### 1. Tambah Device Mikrotik

1. Buka aplikasi di http://localhost:3000
2. Klik tombol **"Tambah Device"**
3. Isi form dengan informasi berikut:
   - **Nama Device**: Nama identifikasi (contoh: "Router Utama")
   - **Host/IP Address**: IP Mikrotik (contoh: "192.168.1.1")
   - **Port API**: 8728 (default)
   - **Username**: admin atau user backup
   - **Password**: password user

4. Klik **"Tambah Device"**

### 2. Test Koneksi

1. Setelah device ditambahkan, klik tombol **"Test"**
2. Tunggu beberapa saat (simulasi koneksi)
3. Jika berhasil, akan muncul notifikasi ✅
4. Jika gagal, periksa:
   - Koneksi network ke Mikrotik
   - API service sudah aktif
   - Username dan password benar
   - Port tidak diblokir firewall

### 3. Buat Backup Manual

1. Klik tombol **"Backup"** pada device yang diinginkan
2. Tunggu proses backup selesai
3. Backup akan tersimpan di database

### 4. Lihat History Backup

1. Pindah ke tab **"Backup History"**
2. Lihat semua backup yang telah dibuat
3. Status:
   - ✅ **Success**: Backup berhasil
   - ❌ **Failed**: Backup gagal
4. Download backup dengan klik tombol 📥

### 5. Jadwalkan Backup Otomatis

1. Pindah ke tab **"Jadwal Backup"**
2. Klik **"Tambah Jadwal"**
3. Konfigurasi:
   - **Device**: Pilih perangkat
   - **Nama Jadwal**: Nama identifikasi (contoh: "Backup Harian")
   - **Cron Expression**: Jadwal eksekusi
   - **Tipe Backup**: Full Backup atau Config Only

#### 📅 Cron Expression Examples:

```
0 2 * * *     = Setiap hari jam 02:00 pagi
30 14 * * 1-5  = Senin-Jumat jam 14:30
0 0 1 * *     = Setiap tanggal 1 jam 00:00
0 6 * * 0     = Setiap Minggu jam 06:00 pagi
*/15 * * * *  = Setiap 15 menit
```

**Format Cron**: `Menit Jam Hari Bulan HariMinggu`
- Menit: 0-59
- Jam: 0-23  
- Hari: 1-31
- Bulan: 1-12
- HariMinggu: 0-7 (0 dan 7 = Minggu)

## 📁 Backup Files

Backup akan tersimpan dengan format:
- **Filename**: `backup-nama-device-timestamp.backup`
- **Content**: Konfigurasi lengkap Mikrotik
- **Size**: Ukuran file backup

## 🔍 Troubleshooting

### Koneksi Gagal
```bash
# Cek API service Mikrotik
/ip service print

# Pastikan API enabled
/ip service enable api

# Cek port
/tool netwatch host=192.168.1.1 port=8728
```

### Backup Gagal
- Pastikan device memiliki cukup storage
- Cek log error di console browser
- Verifikasi koneksi masih aktif

### Jadwal Tidak Jalan
- Pastikan cron expression valid
- Check status schedule (harus aktif)
- Restart aplikasi jika perlu

## 🛡️ Keamanan

- Gunakan password yang kuat
- Batasi akses API ke IP tertentu
- Regular backup schedule
- Monitor backup history
- Store backups in secure location

## 📞 Support

Jika mengalami masalah:
1. Cek console browser untuk error details
2. Verify Mikrotik configuration
3. Test network connectivity
4. Review logs di server

---

**Note**: Aplikasi ini menggunakan mode simulasi untuk demo. Untuk production, implement actual Mikrotik API integration.