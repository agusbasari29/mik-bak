import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const backup = await db.backup.findUnique({
      where: { id: params.id },
      include: {
        device: {
          select: {
            name: true
          }
        }
      }
    })

    if (!backup) {
      return NextResponse.json({ error: 'Backup not found' }, { status: 404 })
    }

    if (backup.status !== 'success') {
      return NextResponse.json({ error: 'Backup not available for download' }, { status: 400 })
    }

    // Create download response
    const response = new NextResponse(backup.content, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${backup.filename}"`,
        'Content-Length': backup.size.toString()
      }
    })

    return response
  } catch (error) {
    console.error('Error downloading backup:', error)
    return NextResponse.json({ error: 'Failed to download backup' }, { status: 500 })
  }
}