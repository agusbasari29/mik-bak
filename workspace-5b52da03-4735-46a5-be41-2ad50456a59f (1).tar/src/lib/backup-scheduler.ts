import { db } from '@/lib/db'
import { MikrotikAPISimple } from './mikrotik-api-simple'

export class BackupScheduler {
  private static instance: BackupScheduler
  private intervals: Map<string, NodeJS.Timeout> = new Map()

  private constructor() {
    this.startScheduler()
  }

  static getInstance(): BackupScheduler {
    if (!BackupScheduler.instance) {
      BackupScheduler.instance = new BackupScheduler()
    }
    return BackupScheduler.instance
  }

  private async startScheduler() {
    // Load all active schedules
    const schedules = await db.backupSchedule.findMany({
      where: { isActive: true },
      include: { device: true }
    })

    for (const schedule of schedules) {
      this.scheduleBackup(schedule)
    }
  }

  scheduleBackup(schedule: any) {
    // Clear existing interval for this schedule
    if (this.intervals.has(schedule.id)) {
      clearInterval(this.intervals.get(schedule.id)!)
    }

    // Parse cron expression (simplified - only supports basic patterns)
    const interval = this.parseCronToInterval(schedule.cronExpression)
    
    if (interval) {
      const timeout = setInterval(async () => {
        await this.executeScheduledBackup(schedule)
      }, interval)
      
      this.intervals.set(schedule.id, timeout)
    }
  }

  private parseCronToInterval(cronExpression: string): number | null {
    // Simplified cron parsing - only supports basic patterns
    // Format: "minute hour day month dayOfWeek"
    const parts = cronExpression.split(' ')
    
    if (parts.length !== 5) return null

    const [minute, hour, day, month, dayOfWeek] = parts

    // For daily backup at specific time (e.g., "0 2 * * *")
    if (minute !== '*' && hour !== '*' && day === '*' && month === '*' && dayOfWeek === '*') {
      const minutes = parseInt(minute)
      const hours = parseInt(hour)
      
      if (!isNaN(minutes) && !isNaN(hours)) {
        // Calculate milliseconds until next run
        const now = new Date()
        const nextRun = new Date()
        nextRun.setHours(hours, minutes, 0, 0)
        
        // If time has passed today, schedule for tomorrow
        if (nextRun <= now) {
          nextRun.setDate(nextRun.getDate() + 1)
        }
        
        const timeUntilNext = nextRun.getTime() - now.getTime()
        
        // Schedule first run
        setTimeout(() => {
          this.executeScheduledBackup(this.getScheduleById(cronExpression))
          // Then set up recurring interval
          return 24 * 60 * 60 * 1000 // 24 hours
        }, timeUntilNext)
        
        return 24 * 60 * 60 * 1000 // 24 hours for recurring
      }
    }

    // Default to hourly if we can't parse
    return 60 * 60 * 1000
  }

  private async getScheduleById(cronExpression: string): Promise<any> {
    const schedule = await db.backupSchedule.findFirst({
      where: { cronExpression },
      include: { device: true }
    })
    return schedule
  }

  private async executeScheduledBackup(schedule: any) {
    try {
      console.log(`Executing scheduled backup: ${schedule.name} for device: ${schedule.device.name}`)

      // Create backup record
      const backup = await db.backup.create({
        data: {
          deviceId: schedule.deviceId,
          filename: `scheduled-backup-${schedule.device.name}-${new Date().toISOString().replace(/[:.]/g, '-')}.backup`,
          backupType: schedule.backupType,
          status: 'pending',
          size: 0,
          content: ''
        }
      })

      try {
        const api = new MikrotikAPISimple(
          schedule.device.host,
          schedule.device.port,
          schedule.device.username,
          schedule.device.password
        )
        
        const backupData = await api.createBackup(schedule.backupType)

        // Update backup record with success
        await db.backup.update({
          where: { id: backup.id },
          data: {
            content: backupData.content,
            size: backupData.size,
            status: 'success'
          }
        })

        // Update schedule last run
        await db.backupSchedule.update({
          where: { id: schedule.id },
          data: {
            lastRun: new Date()
          }
        })

        console.log(`Scheduled backup completed successfully: ${schedule.name}`)
      } catch (backupError) {
        // Update backup record with error
        await db.backup.update({
          where: { id: backup.id },
          data: {
            status: 'failed',
            errorMessage: backupError.message
          }
        })

        console.error(`Scheduled backup failed: ${schedule.name}`, backupError)
      }
    } catch (error) {
      console.error('Error executing scheduled backup:', error)
    }
  }

  async addSchedule(schedule: any) {
    if (schedule.isActive) {
      this.scheduleBackup(schedule)
    }
  }

  async removeSchedule(scheduleId: string) {
    if (this.intervals.has(scheduleId)) {
      clearInterval(this.intervals.get(scheduleId)!)
      this.intervals.delete(scheduleId)
    }
  }

  async updateSchedule(schedule: any) {
    await this.removeSchedule(schedule.id)
    if (schedule.isActive) {
      this.scheduleBackup(schedule)
    }
  }

  stop() {
    for (const interval of this.intervals.values()) {
      clearInterval(interval)
    }
    this.intervals.clear()
  }
}

// Initialize scheduler
export const backupScheduler = BackupScheduler.getInstance()