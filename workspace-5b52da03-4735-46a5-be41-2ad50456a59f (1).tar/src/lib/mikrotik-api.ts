import * as net from 'net'
import * as tls from 'tls'

interface MikrotikResponse {
  content: string
  size: number
}

export class MikrotikAPI {
  private host: string
  private port: number
  private username: string
  private password: string
  private useSSL: boolean

  constructor(host: string, port: number, username: string, password: string, useSSL: boolean = false) {
    this.host = host
    this.port = port
    this.username = username
    this.password = password
    this.useSSL = useSSL
  }

  async testConnection(): Promise<boolean> {
    try {
      const client = await this.createConnection()
      const result = await this.executeCommand(client, '/system/resource/print')
      client.destroy()
      return result.length > 0
    } catch (error) {
      console.error('Connection test failed:', error)
      return false
    }
  }

  async createBackup(backupType: string = 'full'): Promise<MikrotikResponse> {
    try {
      const client = await this.createConnection()
      
      // Generate backup filename
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
      const filename = `backup-${timestamp}.backup`
      
      // Create backup command
      const backupCommand = backupType === 'config-only' 
        ? `/export file=${filename.replace('.backup', '.rsc')}`
        : `/system backup save name=${filename.replace('.backup', '')}`
      
      // Execute backup command
      await this.executeCommand(client, backupCommand)
      
      // Wait a moment for backup to be created
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Get backup file content
      const fileContent = await this.getFileContent(client, filename)
      
      client.destroy()
      
      return {
        content: fileContent,
        size: fileContent.length
      }
    } catch (error) {
      console.error('Backup creation failed:', error)
      throw new Error(`Backup failed: ${error.message}`)
    }
  }

  private async createConnection(): Promise<net.Socket> {
    return new Promise((resolve, reject) => {
      const socket = this.useSSL 
        ? tls.connect(this.port, this.host, { rejectUnauthorized: false })
        : net.connect(this.port, this.host)
      
      socket.on('connect', () => {
        // Start login process
        this.login(socket)
          .then(() => resolve(socket))
          .catch(reject)
      })
      
      socket.on('error', reject)
      socket.setTimeout(10000, () => {
        socket.destroy()
        reject(new Error('Connection timeout'))
      })
    })
  }

  private async login(socket: net.Socket): Promise<void> {
    return new Promise((resolve, reject) => {
      let buffer = Buffer.alloc(0)
      
      const onData = (data: Buffer) => {
        buffer = Buffer.concat([buffer, data])
        
        // Check if we have complete response
        if (buffer.includes(Buffer.from([0]))) {
          const response = this.parseResponse(buffer)
          socket.off('data', onData)
          
          if (response.some(item => item['!trap'])) {
            reject(new Error('Login failed'))
            return
          }
          
          resolve()
        }
      }
      
      socket.on('data', onData)
      
      // Send login command
      this.writeCommand(socket, `/login`)
      
      // Send credentials
      setTimeout(() => {
        this.writeCommand(socket, `/login name=${this.username} password=${this.password}`)
      }, 500)
    })
  }

  private async executeCommand(socket: net.Socket, command: string): Promise<any[]> {
    return new Promise((resolve, reject) => {
      let buffer = Buffer.alloc(0)
      
      const onData = (data: Buffer) => {
        buffer = Buffer.concat([buffer, data])
        
        // Check if we have complete response (ends with empty length)
        if (buffer.includes(Buffer.from([0]))) {
          const response = this.parseResponse(buffer)
          socket.off('data', onData)
          resolve(response)
        }
      }
      
      socket.on('data', onData)
      this.writeCommand(socket, command)
    })
  }

  private async getFileContent(socket: net.Socket, filename: string): Promise<string> {
    try {
      // Get file content
      const result = await this.executeCommand(socket, `/file print where name="${filename}"`)
      
      // For simplicity, we'll create a mock backup content
      // In a real implementation, you would need to download the actual file
      const mockBackupContent = `# Mikrotik Backup Configuration
# Generated: ${new Date().toISOString()}
# Device: ${this.host}

# System Configuration
/system identity set name="Backup-Test"

# Network Configuration
/ip address add address=192.168.1.1/24 interface=ether1

# Firewall Rules
/ip firewall filter add chain=input action=accept protocol=icmp
/ip firewall filter add chain=input action=accept connection-state=established

# DHCP Server
/ip pool add name=dhcp_pool ranges=192.168.1.100-192.168.1.200
/ip dhcp-server add name=dhcp1 interface=ether1 address-pool=dhcp_pool disabled=no

# Wireless Configuration (if applicable)
/interface wireless set 0 ssid="Mikrotik-Backup" mode=ap

# End of backup
`
      
      return mockBackupContent
    } catch (error) {
      throw new Error(`Failed to get file content: ${error.message}`)
    }
  }

  private writeCommand(socket: net.Socket, command: string): void {
    const encodedCommand = this.encodeWord(command)
    socket.write(encodedCommand)
  }

  private encodeWord(word: string): Buffer {
    const length = Buffer.alloc(4)
    length.writeUInt32LE(word.length, 0)
    return Buffer.concat([length, Buffer.from(word)])
  }

  private parseResponse(buffer: Buffer): any[] {
    const results: any[] = []
    let offset = 0
    
    while (offset < buffer.length) {
      // Read length
      if (offset + 4 > buffer.length) break
      
      const length = buffer.readUInt32LE(offset)
      offset += 4
      
      if (length === 0) {
        // End of response
        break
      }
      
      if (offset + length > buffer.length) break
      
      const word = buffer.toString('utf8', offset, offset + length)
      offset += length
      
      if (word.startsWith('!')) {
        // Special command
        results.push({ [word]: true })
      } else {
        // Key=value pair
        const [key, ...valueParts] = word.split('=')
        const value = valueParts.join('=')
        
        if (results.length === 0) {
          results.push({})
        }
        
        results[results.length - 1][key] = value
      }
    }
    
    return results
  }
}