# Mikrotik Daily Backup

Aplikasi web untuk mengelola backup otomatis perangkat Mikrotik dengan fitur penjadwalan dan monitoring.

## Fitur

- **Manajemen Device**: Tambah, edit, dan hapus perangkat Mikrotik
- **Backup Manual**: Buat backup sesuai kebutuhan
- **Backup Otomatis**: Jadwalkan backup harian dengan cron expression
- **Monitoring**: Pantau status backup dan history
- **Download**: Unduh file backup yang berhasil dibuat
- **Test Koneksi**: Verifikasi koneksi ke perangkat Mikrotik

## Teknologi

- **Frontend**: Next.js 15, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: SQLite
- **API**: Mikrotik API integration

## Instalasi

1. Clone repository
```bash
git clone <repository-url>
cd mikrotik-daily-backup
```

2. Install dependencies
```bash
npm install
```

3. Setup database
```bash
npm run db:push
```

4. Jalankan development server
```bash
npm run dev
```

5. Buka [http://localhost:3000](http://localhost:3000)

## Penggunaan

### 1. Tambah Device Mikrotik

- Klik tombol "Tambah Device"
- Isi form dengan informasi perangkat:
  - Nama Device: Nama identifikasi perangkat
  - Host/IP Address: Alamat IP perangkat Mikrotik
  - Port API: Port API Mikrotik (default: 8728)
  - Username: Username API
  - Password: Password API

### 2. Test Koneksi

- Setelah menambah device, klik tombol "Test" untuk memverifikasi koneksi
- Pastikan API Mikrotik sudah aktif dan dapat diakses

### 3. Buat Backup Manual

- Klik tombol "Backup" pada device yang diinginkan
- Tipe backup yang tersedia:
  - Full Backup: Backup lengkap konfigurasi
  - Config Only: Hanya konfigurasi saja

### 4. Jadwalkan Backup Otomatis

- Pindah ke tab "Jadwal Backup"
- Klik "Tambah Jadwal"
- Konfigurasi jadwal:
  - Device: Pilih perangkat yang akan di-backup
  - Nama Jadwal: Nama identifikasi jadwal
  - Cron Expression: Format cron untuk penjadwalan
    - Contoh: `0 2 * * *` (Setiap hari jam 2 pagi)
    - Format: `Menit Jam Hari Bulan HariMinggu`
  - Tipe Backup: Pilih tipe backup yang diinginkan

### 5. Monitoring dan Download

- Tab "Backup History" menampilkan semua backup yang telah dibuat
- Status backup:
  - ✅ Success: Backup berhasil
  - ❌ Failed: Backup gagal
- Download backup yang berhasil dengan klik tombol download

## Konfigurasi Mikrotik

Pastikan layanan API Mikrotik sudah aktif:

```bash
/ip service enable api
/ip service set api port=8728 address=0.0.0.0
```

Untuk keamanan, disarankan:
- Batasi akses API ke IP tertentu
- Gunakan username dan password yang kuat
- Aktifkan SSL/TLS jika memungkinkan

## Cron Expression

Format cron yang didukung:

```
* * * * *
│ │ │ │ │
│ │ │ │ └─── Hari Minggu (0-7, 0 dan 7 = Minggu)
│ │ │ └───── Bulan (1-12)
│ │ └─────── Hari (1-31)
│ └───────── Jam (0-23)
└─────────── Menit (0-59)
```

Contoh umum:
- `0 2 * * *` - Setiap hari jam 2 pagi
- `30 14 * * 1-5` - Senin-Jumat jam 14:30
- `0 0 1 * *` - Setiap tanggal 1 jam 00:00
- `0 6 * * 0` - Setiap Minggu jam 6 pagi

## API Endpoints

### Devices
- `GET /api/devices` - Get all devices
- `POST /api/devices` - Create new device
- `POST /api/devices/[id]/test` - Test connection to device

### Backups
- `GET /api/backups` - Get all backups
- `POST /api/backups` - Create new backup
- `GET /api/backups/[id]/download` - Download backup file

### Schedules
- `GET /api/schedules` - Get all schedules
- `POST /api/schedules` - Create new schedule
- `PUT /api/schedules/[id]` - Update schedule
- `DELETE /api/schedules/[id]` - Delete schedule

## Troubleshooting

### Koneksi Gagal
- Pastikan API Mikrotik aktif (`/ip service print`)
- Cek firewall yang memblokir port API
- Verifikasi username dan password API
- Pastikan address API mengizinkan akses dari IP server

### Backup Gagal
- Periksa koneksi ke device
- Pastikan ada cukup space di device
- Cek log error untuk detail masalah

### Jadwal Tidak Berjalan
- Verifikasi cron expression valid
- Pastikan schedule dalam status aktif
- Cek log server untuk error

## Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Run linting
npm run lint
```

## License

MIT License